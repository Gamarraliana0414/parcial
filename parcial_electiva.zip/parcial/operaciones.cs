﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System;
using System.Linq;

public static class Operaciones
{
    public static double Potencia(int baseNum, int exponente)
    {
        return Math.Pow(baseNum, exponente);
    }

    public static bool EsPar(int numero)
    {
        return numero % 2 == 0;
    }

    public static bool EsPalindromo(string texto)
    {
        string limpio = new string(texto.Where(char.IsLetterOrDigit).ToArray()).ToLower();
        return limpio == new string(limpio.Reverse().ToArray());
    }

    public static bool EsPrimo(int numero)
    {
        if (numero < 2) return false;
        for (int i = 2; i * i <= numero; i++)
        {
            if (numero % i == 0) return false;
        }
        return true;
    }

    public static long Factorial(int numero)
    {
        if (numero < 0) throw new ArgumentException("El número debe ser no negativo.");
        long resultado = 1;
        for (int i = 2; i <= numero; i++)
        {
            resultado *= i;
        }
        return resultado;
    }

    public static string InvertirCadena(string texto)
    {
        return new string(texto.Reverse().ToArray());
    }

    public static int ContarVocales(string texto)
    {
        return texto.Count(c => "aeiouAEIOU".Contains(c));
    }

    public static int SumarDigitos(int numero)
    {
        return Math.Abs(numero).ToString().Sum(c => c - '0');
    }

    public static int Fibonacci(int n)
    {
        if (n < 0) throw new ArgumentException("El índice debe ser no negativo.");
        if (n == 0) return 0;
        if (n == 1) return 1;

        int a = 0, b = 1;
        for (int i = 2; i <= n; i++)
        {
            int temp = a + b;
            a = b;
            b = temp;
        }
        return b;
    }
}
