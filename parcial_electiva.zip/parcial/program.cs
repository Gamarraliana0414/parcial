﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace parcial
{
    class Program
    {
        static void Main()
        {
            int opcion;
            do
            {
                Console.WriteLine("\nMenú de Operaciones:");
                Console.WriteLine("1. Calcular Potencia");
                Console.WriteLine("2. Verificar si es Par");
                Console.WriteLine("3. Verificar si es Palíndromo");
                Console.WriteLine("4. Verificar si es Primo");
                Console.WriteLine("5. Calcular Factorial");
                Console.WriteLine("6. Invertir Cadena");
                Console.WriteLine("7. Contar Vocales");
                Console.WriteLine("8. Sumar Dígitos");
                Console.WriteLine("9. Calcular Fibonacci");
                Console.WriteLine("0. Salir");
                Console.Write("Seleccione una opción: ");
                if (!int.TryParse(Console.ReadLine(), out opcion))
                {
                    Console.WriteLine("Entrada no válida. Intente de nuevo.");
                    continue;
                }

                switch (opcion)
                {
                    case 1:
                        Console.Write("Ingrese la base: ");
                        if (!int.TryParse(Console.ReadLine(), out int baseNum)) break;
                        Console.Write("Ingrese el exponente: ");
                        if (!int.TryParse(Console.ReadLine(), out int exponente)) break;
                        Console.WriteLine("Resultado: " + Operaciones.Potencia(baseNum, exponente));
                        break;
                    case 2:
                        Console.Write("Ingrese un número: ");
                        if (!int.TryParse(Console.ReadLine(), out int numPar)) break;
                        Console.WriteLine("Es par: " + Operaciones.EsPar(numPar));
                        break;
                    case 3:
                        Console.Write("Ingrese una cadena: ");
                        string texto = Console.ReadLine() ?? "";
                        Console.WriteLine("Es palíndromo: " + Operaciones.EsPalindromo(texto));
                        break;
                    case 4:
                        Console.Write("Ingrese un número: ");
                        if (!int.TryParse(Console.ReadLine(), out int numPrimo)) break;
                        Console.WriteLine("Es primo: " + Operaciones.EsPrimo(numPrimo));
                        break;
                    case 5:
                        Console.Write("Ingrese un número: ");
                        if (!int.TryParse(Console.ReadLine(), out int numFactorial)) break;
                        Console.WriteLine("Factorial: " + Operaciones.Factorial(numFactorial));
                        break;
                    case 6:
                        Console.Write("Ingrese una cadena: ");
                        string cadena = Console.ReadLine() ?? "";
                        Console.WriteLine("Cadena invertida: " + Operaciones.InvertirCadena(cadena));
                        break;
                    case 7:
                        Console.Write("Ingrese una cadena: ");
                        string cadenaVocales = Console.ReadLine() ?? "";
                        Console.WriteLine("Número de vocales: " + Operaciones.ContarVocales(cadenaVocales));
                        break;
                    case 8:
                        Console.Write("Ingrese un número: ");
                        if (!int.TryParse(Console.ReadLine(), out int numDigitos)) break;
                        Console.WriteLine("Suma de dígitos: " + Operaciones.SumarDigitos(numDigitos));
                        break;
                    case 9:
                        Console.Write("Ingrese un índice de Fibonacci: ");
                        if (!int.TryParse(Console.ReadLine(), out int n)) break;
                        Console.WriteLine("Número de Fibonacci: " + Operaciones.Fibonacci(n));
                        break;
                    case 0:
                        Console.WriteLine("Saliendo...");
                        break;
                    default:
                        Console.WriteLine("Opción no válida. Intente de nuevo.");
                        break;
                }
            } while (opcion != 0);
        }
    }
}
